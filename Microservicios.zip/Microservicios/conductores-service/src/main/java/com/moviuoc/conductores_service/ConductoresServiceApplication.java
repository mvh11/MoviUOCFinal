package com.moviuoc.conductores_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConductoresServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConductoresServiceApplication.class, args);
	}

}
