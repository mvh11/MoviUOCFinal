package com.moviuoc.conductores_service.controller;

import com.moviuoc.conductores_service.model.Conductor;
import com.moviuoc.conductores_service.repository.ConductorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/conductores")
@CrossOrigin(origins = "*")
public class ConductorController {

    private final ConductorRepository repo;

    public ConductorController(ConductorRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Conductor> getAll() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Conductor> getById(@PathVariable Long id) {
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Conductor create(@RequestBody Conductor c) {
        c.setId(null);
        return repo.save(c);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Conductor> update(@PathVariable Long id,
                                            @RequestBody Conductor conductor) {
        return repo.findById(id)
                .map(existing -> {
                    existing.setNombre(conductor.getNombre());
                    existing.setEmail(conductor.getEmail());
                    existing.setTelefono(conductor.getTelefono());
                    existing.setPatente(conductor.getPatente());
                    existing.setLicencia(conductor.getLicencia());
                    existing.setUsuarioId(conductor.getUsuarioId());
                    return ResponseEntity.ok(repo.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();

        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
