package com.moviuoc.viajes_service.model;

import jakarta.persistence.*;

@Entity
@Table(name = "VIAJES")
public class Viaje {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long conductorId;
    private Long fechaMillis;
    private Integer cupos;
    private String origen;
    private String destino;
    private Integer precio;

    public Viaje() {}

    // getters & setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getConductorId() { return conductorId; }
    public void setConductorId(Long conductorId) { this.conductorId = conductorId; }

    public Long getFechaMillis() { return fechaMillis; }
    public void setFechaMillis(Long fechaMillis) { this.fechaMillis = fechaMillis; }

    public Integer getCupos() { return cupos; }
    public void setCupos(Integer cupos) { this.cupos = cupos; }

    public String getOrigen() { return origen; }
    public void setOrigen(String origen) { this.origen = origen; }

    public String getDestino() { return destino; }
    public void setDestino(String destino) { this.destino = destino; }

    public Integer getPrecio() { return precio; }
    public void setPrecio(Integer precio) { this.precio = precio; }
}
