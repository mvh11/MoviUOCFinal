package com.moviuoc.viajes_service.repository;

import com.moviuoc.viajes_service.model.Viaje;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ViajeRepository extends JpaRepository<Viaje, Long> {
}
