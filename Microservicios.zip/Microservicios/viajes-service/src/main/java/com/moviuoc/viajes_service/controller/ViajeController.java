package com.moviuoc.viajes_service.controller;

import com.moviuoc.viajes_service.model.Viaje;
import com.moviuoc.viajes_service.repository.ViajeRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/viajes")
@CrossOrigin(origins = "*")
public class ViajeController {

    private final ViajeRepository repo;

    public ViajeController(ViajeRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Viaje> getAll() {
        return repo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Viaje> getById(@PathVariable Long id) {
        return repo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Viaje create(@RequestBody Viaje viaje) {
        viaje.setId(null);
        return repo.save(viaje);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Viaje> update(@PathVariable Long id,
                                        @RequestBody Viaje viaje) {
        return repo.findById(id)
                .map(existing -> {
                    existing.setConductorId(viaje.getConductorId());
                    existing.setFechaMillis(viaje.getFechaMillis());
                    existing.setCupos(viaje.getCupos());
                    existing.setOrigen(viaje.getOrigen());
                    existing.setDestino(viaje.getDestino());
                    existing.setPrecio(viaje.getPrecio());
                    return ResponseEntity.ok(repo.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();

        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
